# progenax Mass Segregation: Developer Design & Implementation Guide

**Version:** 1.1 (December 2025)  
**Module:** `progenax.segregation`  
**Audience:** Developers implementing, maintaining, and testing the mass segregation module

---

## Table of Contents

1. [Overview & Scope](#1-overview--scope)
2. [Inputs, Outputs, and Data Flow](#2-inputs-outputs-and-data-flow)
3. [Method A (Blending) – Implementation Details](#3-method-a-blending--implementation-details)
4. [Mass-Dependent Segregation λ_seg(m) – Implementation](#4-mass-dependent-segregation-λ_segm--implementation)
5. [Method B (OT) – Experimental Implementation](#5-method-b-ot--experimental-implementation)
6. [Unified API & Configuration](#6-unified-api--configuration)
7. [Testing Strategy](#7-testing-strategy)
8. [Performance & Scaling Notes](#8-performance--scaling-notes)
9. [Integration Points](#9-integration-points)
10. [Visualization Hooks for Methods Paper](#10-visualization-hooks-for-methods-paper)

---

## 1. Overview & Scope

The mass segregation module provides **differentiable assignment of orbits to stars** based on mass-energy correlation. Given stellar masses sampled from an IMF and a pool of phase-space orbits from an equilibrium distribution function, this module assigns orbits to stars such that more massive stars preferentially occupy more bound (deeper) orbits.

The key innovation is that the mapping is **continuously parameterized** by $\lambda_{\text{seg}} \in [0, 1]$, enabling gradient-based inference over the segregation strength:

- $\lambda_{\text{seg}} = 0$: No segregation (random orbit assignment)
- $\lambda_{\text{seg}} = 1$: Full segregation (Baumgardt-style rank matching)
- Intermediate values: Smooth interpolation

### 1.1 Design Invariants

The module is designed around two core invariants that all implementations must satisfy:

**Differentiability invariant:**
> Gradients are guaranteed to flow through segregation parameters ($\lambda_{\text{seg}}$, $\lambda_{\text{base}}$, $\lambda_{\text{slope}}$, OT hyperparameters) and structural parameters (profile, FDF). Gradients do **not** flow through IMF parameters via discrete orbit assignments—the `argsort`-based rankings are intentionally wrapped in `stop_gradient`.

**Statistical invariant:**
> The mapping must **monotonically increase** mass segregation metrics ($\Lambda_{\text{MSR}}$, mass–energy rank correlation $\rho_{\text{ME}}$, mass–radius correlation) as $\lambda_{\text{seg}}$ increases from 0 → 1. All validation tests (§7) confirm this invariant.

### 1.2 Method Selection

| Method | Status | Complexity | Use Case |
|--------|--------|------------|----------|
| **Method A (Blending)** | **Production default** | $O(N \log N)$ | All applications |
| Method B (OT) | Experimental | $O(N^2)$ | Methods papers, $N \lesssim 10^4$ |

**Implementation priority:** Method A is the v1 target. Method B should NOT block integration of the FDF + Method A pipeline.

---

## 2. Inputs, Outputs, and Data Flow

### 2.1 Function Signature

```python
def assign_orbits_mass_seg(
    key: PRNGKey,
    masses: Array,              # (N,) stellar masses
    orbit_positions: Array,     # (N_pool, 3) positions from equilibrium DF
    orbit_velocities: Array,    # (N_pool, 3) velocities from equilibrium DF
    energies: Array,            # (N_pool,) specific energies
    method: str = "blend",      # "blend" (default) or "ot"
    params: SegregationParams,  # BlendingSegregationParams or OTSegregationParams
) -> tuple[Array, Array]:       # (positions, velocities) both (N, 3)
```

### 2.2 Input Requirements

| Input | Shape | Constraints | Notes |
|-------|-------|-------------|-------|
| `masses` | `(N,)` | $N > 1$, positive values | From IMF sampling |
| `orbit_positions` | `(N_{\text{pool}}, 3)` | $N_{\text{pool}} \geq N$ | From DF sampler |
| `orbit_velocities` | `(N_{\text{pool}}, 3)` | Same length as positions | From DF sampler |
| `energies` | `(N_{\text{pool}},)` | Typically negative (bound) | $e_j = \frac{1}{2}|\mathbf{v}_j|^2 + \Phi(\mathbf{x}_j)$ |
| `key` | `PRNGKey` | Valid JAX key | For random assignment |

**Pool factor:** Typically $N_{\text{pool}} = 4N$ (set upstream via `pool_factor` parameter).

#### Energy Convention

> **Important:** We assume the DF sampler returns **bound orbits with negative specific energy** ($e < 0$). The energy ranking sorts ascending, so more negative (more bound) orbits come first.
>
> If unbound orbits appear ($e \geq 0$), they will naturally be placed at the high-energy (least bound) end of the ranking and will be assigned primarily to low-mass stars at high $\lambda_{\text{seg}}$. This is physically reasonable behavior but may indicate an issue with the upstream DF sampler if many orbits are unbound.

In the OT implementation, we explicitly handle this:
```python
binding_energy = jnp.maximum(-energies, 1e-10)  # Clamp to positive
```

### 2.3 Output Guarantees

- Positions and velocities are post-processed for virial equilibrium
- COM velocity removed
- Positions centered on COM
- Shapes: both `(N, 3)`

### 2.4 Pipeline Diagram

```
┌─────────────────────────────────────────────────────────────────────┐
│                    PROGENAX IC GENERATION PIPELINE                   │
└─────────────────────────────────────────────────────────────────────┘

                      ┌──────────────────┐
                      │   θ_IMF          │
                      │ (α, m_break)     │
                      └────────┬─────────┘
                               │
                               ▼
                      ┌──────────────────┐
                      │  sample_imf()    │
                      │  → masses (N,)   │
                      └────────┬─────────┘
                               │
       ┌───────────────────────┼───────────────────────┐
       │                       │                       │
       ▼                       ▼                       │
┌─────────────────┐   ┌─────────────────┐              │
│ θ_profile       │   │ Stellar physics │              │
│ (r_h, γ, etc)   │   │ (colors, L)     │              │
└───────┬─────────┘   └─────────────────┘              │
        │                                              │
        ▼                                              │
┌─────────────────┐                                    │
│ sample_df()     │                                    │
│ → orbit_pool    │                                    │
└───────┬─────────┘                                    │
        │                                              │
        ▼                                              │
┌─────────────────────────────────────────────────────┐
│           MASS SEGREGATION (this module)            │
│                                                     │
│  ┌─────────────────────────────────────────────┐   │
│  │  λ_seg ──────────────────────────────────┐  │   │
│  │                                          │  │   │
│  │  pos_i = (1-λ) * pos_rand + λ * pos_seg  │  │   │
│  │  vel_i = (1-λ) * vel_rand + λ * vel_seg  │  │   │
│  │                                          │  │   │
│  │  ∂pos_i/∂λ = pos_seg - pos_rand         │  │   │
│  │  (always nonzero!)                       │  │   │
│  └──────────────────────────────────────────┘   │
└───────────────────────┬─────────────────────────────┘
                        │
                        ▼
              ┌──────────────────┐
              │ FDF displacement │  ← Optional: λ_frac
              │ (spatial clumps) │
              └────────┬─────────┘
                       │
                       ▼
              ┌──────────────────┐
              │ virialize()      │  ← Q_vir target
              │ + COM removal    │
              └────────┬─────────┘
                       │
                       ▼
              ┌──────────────────┐
              │ IC Snapshot      │
              │ (x, v, m)        │
              └──────────────────┘
```

---

## 3. Method A (Blending) – Implementation Details

### 3.1 Algorithm Overview

1. **Random assignment**: Sample $N$ orbits uniformly without replacement from pool
2. **Segregated assignment**: Match mass rank $k$ to energy rank $j_k$
3. **Blend**: Linear interpolation in phase space
4. **Post-process**: Rescale to target virial ratio, remove COM

### 3.2 Step 1: Random Assignment

```python
# Sample N indices without replacement
key, subkey = random.split(key)
rand_indices = random.choice(subkey, N_pool, shape=(N,), replace=False)

# Freeze random selection (no gradients through sampling)
rand_indices = jax.lax.stop_gradient(rand_indices)

pos_rand = orbit_positions[rand_indices]  # (N, 3)
vel_rand = orbit_velocities[rand_indices]  # (N, 3)
```

**Key point:** The random indices are wrapped in `stop_gradient`. We do NOT rely on gradients through the discrete sampling—only through $\lambda_{\text{seg}}$.

### 3.3 Step 2: Segregated Assignment

```python
# Mass ranking (descending: most massive first)
mass_order = jnp.argsort(-masses)  # (N,)

# Energy ranking (ascending: most bound first)
energy_order = jnp.argsort(energies)  # (N_pool,)

# Freeze permutations (piecewise constant, no useful gradients)
mass_order = jax.lax.stop_gradient(mass_order)
energy_order = jax.lax.stop_gradient(energy_order)

# Map mass rank k to energy rank j_k (compressed if N_pool > N)
k = jnp.arange(N)
j_k = jnp.floor(k / (N - 1) * (N_pool - 1)).astype(jnp.int32)
j_k = jnp.clip(j_k, 0, N_pool - 1)

# Orbit indices for each mass rank
seg_orbit_indices = energy_order[j_k]  # (N,)

# Positions/velocities for each mass rank
pos_seg_by_rank = orbit_positions[seg_orbit_indices]  # (N, 3)
vel_seg_by_rank = orbit_velocities[seg_orbit_indices]  # (N, 3)

# Map back to original star indices
inverse_mass_order = jnp.argsort(mass_order)
pos_seg = pos_seg_by_rank[inverse_mass_order]  # (N, 3)
vel_seg = vel_seg_by_rank[inverse_mass_order]  # (N, 3)
```

**Mapping formula** (for $N_{\text{pool}} > N$):

$$
j_k = \left\lfloor \frac{k}{N-1} \cdot (N_{\text{pool}} - 1) \right\rfloor
$$

This spreads $N$ stars across the full energy range while preserving monotonicity.

> **Gradient note:** The `argsort`-based permutations are wrapped in `stop_gradient`, so **IMF parameters do not influence the orbit assignment through ranking**. This is intentional: we do not attempt to differentiate through discrete rank operations. The segregation gradient signal flows entirely through $\lambda_{\text{seg}}$.

### 3.4 Step 3: Phase-Space Blending

```python
lambda_seg = jnp.clip(params.lambda_seg, 0.0, 1.0)

positions = (1 - lambda_seg) * pos_rand + lambda_seg * pos_seg
velocities = (1 - lambda_seg) * vel_rand + lambda_seg * vel_seg
```

**Gradient structure:**

$$
\frac{\partial \mathbf{x}_i}{\partial \lambda_{\text{seg}}} = \mathbf{x}_i^{\text{seg}} - \mathbf{x}_i^{\text{rand}}
$$

This is always well-defined and nonzero (unless endpoints coincide, which is astronomically unlikely).

### 3.5 Step 4: Post-Processing

```python
positions, velocities = virialize_and_center(
    positions, velocities, masses, params.virial_ratio, G
)
```

See `virialize_and_center()` implementation in §6.

### 3.6 Complete Implementation

```python
@dataclass(frozen=True)
class BlendingSegregationParams:
    """Parameters for Method A (phase-space blending).
    
    THIS IS THE RECOMMENDED DEFAULT for mass segregation in progenax.
    O(N log N) complexity, trivially differentiable.
    
    Attributes
    ----------
    lambda_seg : float
        Segregation strength in [0, 1].
        0 = no segregation, 1 = full Baumgardt-style.
    pool_factor : int
        Orbit pool multiplier (used upstream, not in this function).
    virial_ratio : float
        Target Q_vir = K/|U| after post-processing.
    """
    lambda_seg: float = 0.5
    pool_factor: int = 4
    virial_ratio: float = 0.5


def blending_segregation(
    key: random.PRNGKey,
    masses: Array,
    orbit_positions: Array,
    orbit_velocities: Array,
    energies: Array,
    params: BlendingSegregationParams,
) -> tuple[Array, Array]:
    """Assign orbits using phase-space blending.
    
    Parameters
    ----------
    key : PRNGKey
    masses : (N,) stellar masses (N must be > 1)
    orbit_positions : (N_pool, 3) positions from equilibrium DF
    orbit_velocities : (N_pool, 3) velocities from equilibrium DF
    energies : (N_pool,) specific energies (negative for bound orbits)
    params : BlendingSegregationParams
    
    Returns
    -------
    positions : (N, 3) assigned positions
    velocities : (N, 3) assigned velocities
    
    Raises
    ------
    AssertionError
        If N < 2 (blending requires at least 2 stars for rank mapping)
    """
    N = masses.shape[0]
    N_pool = orbit_positions.shape[0]
    
    assert N > 1, "Blending segregation requires N > 1"
    
    lambda_seg = jnp.clip(params.lambda_seg, 0.0, 1.0)
    
    # Step 1: Random assignment
    key, subkey = random.split(key)
    rand_indices = random.choice(subkey, N_pool, shape=(N,), replace=False)
    rand_indices = jax.lax.stop_gradient(rand_indices)
    
    pos_rand = orbit_positions[rand_indices]
    vel_rand = orbit_velocities[rand_indices]
    
    # Step 2: Fully segregated assignment
    mass_order = jax.lax.stop_gradient(jnp.argsort(-masses))
    energy_order = jax.lax.stop_gradient(jnp.argsort(energies))
    
    k = jnp.arange(N)
    j_k = jnp.floor(k / (N - 1) * (N_pool - 1)).astype(jnp.int32)
    j_k = jnp.clip(j_k, 0, N_pool - 1)
    
    seg_orbit_indices = energy_order[j_k]
    pos_seg_by_rank = orbit_positions[seg_orbit_indices]
    vel_seg_by_rank = orbit_velocities[seg_orbit_indices]
    
    inverse_mass_order = jnp.argsort(mass_order)
    pos_seg = pos_seg_by_rank[inverse_mass_order]
    vel_seg = vel_seg_by_rank[inverse_mass_order]
    
    # Step 3: Phase-space blending
    positions = (1 - lambda_seg) * pos_rand + lambda_seg * pos_seg
    velocities = (1 - lambda_seg) * vel_rand + lambda_seg * vel_seg
    
    # Step 4: Post-processing
    positions, velocities = virialize_and_center(
        positions, velocities, masses, params.virial_ratio, G
    )
    
    return positions, velocities
```

---

## 4. Mass-Dependent Segregation λ_seg(m) – Implementation

The mass-dependent implementation is a **thin extension of Method A** that replaces a scalar $\lambda_{\text{seg}}$ with a per-star $\lambda_{\text{seg}}(m)$, while reusing the same random and segregated orbit assignment logic. The only change is in the blending step, where each star uses its own interpolation weight.

### 4.1 Motivation

In real clusters, massive stars segregate faster due to dynamical friction. A single $\lambda_{\text{seg}}$ cannot capture this—we need per-star segregation strengths.

### 4.2 Parameterization

**Linear model** (2 parameters):

$$
\lambda_{\text{seg}}(m) = \text{clip}\left[ \lambda_{\text{base}} + \lambda_{\text{slope}} \cdot \log_{10}(m / M_\odot), \; 0, \; 1 \right]
$$

- `lambda_base`: Segregation at 1 $M_\odot$
- `lambda_slope`: Increase per decade of mass

**Interpretation:**
- $\lambda_{\text{slope}} = 0$: All masses equally segregated (recovers scalar $\lambda_{\text{seg}}$ behavior)
- $\lambda_{\text{slope}} > 0$: Massive stars more segregated (physically motivated)
- $\lambda_{\text{slope}} \approx 0.3$: Rough calibration from N-body simulations

**Plausible priors for inference:**
- $\lambda_{\text{base}} \sim \text{Uniform}(0, 1)$
- $\lambda_{\text{slope}} \geq 0$ with a soft prior (e.g., truncated normal or half-normal) since negative slopes are unphysical

We designed $\lambda_{\text{seg}}(m)$ to be a simple linear-in-$\log m$ model to enable clean inference with minimal degeneracies.

### 4.3 Implementation

```python
@dataclass(frozen=True)
class MassDependentSegregationParams:
    """Parameters for mass-dependent segregation.
    
    lambda_seg(m) = clip(lambda_base + lambda_slope * log10(m), 0, 1)
    
    Attributes
    ----------
    lambda_base : float
        Segregation strength at m = 1 M_sun.
    lambda_slope : float
        Increase in segregation per decade of mass.
        0 = uniform segregation (recovers scalar model),
        ~0.3 = physically motivated from N-body calibration.
    pool_factor : int
        Orbit pool multiplier.
    virial_ratio : float
        Target Q_vir after post-processing.
    """
    lambda_base: float = 0.3
    lambda_slope: float = 0.2
    pool_factor: int = 4
    virial_ratio: float = 0.5


def compute_mass_dependent_lambda(
    masses: Array,
    lambda_base: float,
    lambda_slope: float,
) -> Array:
    """Compute per-star segregation strength.
    
    Parameters
    ----------
    masses : (N,) stellar masses in solar masses
    lambda_base : segregation at 1 M_sun
    lambda_slope : increase per dex of mass
    
    Returns
    -------
    lambda_seg : (N,) per-star segregation strengths, clipped to [0, 1]
    """
    log_m = jnp.log10(masses)
    lambda_seg = lambda_base + lambda_slope * log_m
    return jnp.clip(lambda_seg, 0.0, 1.0)


def blending_segregation_mass_dependent(
    key: random.PRNGKey,
    masses: Array,
    orbit_positions: Array,
    orbit_velocities: Array,
    energies: Array,
    params: MassDependentSegregationParams,
) -> tuple[Array, Array]:
    """Mass-dependent blending segregation.
    
    Each star has its own λ_seg(m), allowing massive stars
    to be more segregated than low-mass stars.
    """
    N = masses.shape[0]
    N_pool = orbit_positions.shape[0]
    
    assert N > 1, "Requires N > 1"
    
    # Per-star segregation strength
    lambda_per_star = compute_mass_dependent_lambda(
        masses, params.lambda_base, params.lambda_slope
    )  # (N,)
    
    # Random assignment (same as scalar case)
    key, subkey = random.split(key)
    rand_indices = random.choice(subkey, N_pool, shape=(N,), replace=False)
    rand_indices = jax.lax.stop_gradient(rand_indices)
    
    pos_rand = orbit_positions[rand_indices]
    vel_rand = orbit_velocities[rand_indices]
    
    # Segregated assignment (same as scalar case)
    mass_order = jax.lax.stop_gradient(jnp.argsort(-masses))
    energy_order = jax.lax.stop_gradient(jnp.argsort(energies))
    
    k = jnp.arange(N)
    j_k = jnp.floor(k / (N - 1) * (N_pool - 1)).astype(jnp.int32)
    j_k = jnp.clip(j_k, 0, N_pool - 1)
    
    seg_orbit_indices = energy_order[j_k]
    pos_seg_by_rank = orbit_positions[seg_orbit_indices]
    vel_seg_by_rank = orbit_velocities[seg_orbit_indices]
    
    inverse_mass_order = jnp.argsort(mass_order)
    pos_seg = pos_seg_by_rank[inverse_mass_order]
    vel_seg = vel_seg_by_rank[inverse_mass_order]
    
    # Mass-dependent blending: each star uses its own λ
    lam = lambda_per_star[:, None]  # (N, 1) for broadcasting
    
    positions = (1 - lam) * pos_rand + lam * pos_seg
    velocities = (1 - lam) * vel_rand + lam * vel_seg
    
    # Post-processing
    positions, velocities = virialize_and_center(
        positions, velocities, masses, params.virial_ratio, G
    )
    
    return positions, velocities
```

### 4.4 Gradient Properties

The mass-dependent model remains fully differentiable:

$$
\frac{\partial \mathbf{x}_i}{\partial \lambda_{\text{base}}} = (\mathbf{x}_i^{\text{seg}} - \mathbf{x}_i^{\text{rand}})
$$

$$
\frac{\partial \mathbf{x}_i}{\partial \lambda_{\text{slope}}} = \log_{10}(m_i / M_\odot) \cdot (\mathbf{x}_i^{\text{seg}} - \mathbf{x}_i^{\text{rand}})
$$

Both gradients are nonzero and informative, enabling joint inference over the mass-dependence.

> **Important clarification:** IMF parameters ($\alpha$, $m_{\text{break}}$, etc.) can still affect downstream observables via stellar evolution, luminosities, colors, and the mass function itself—but **not** via reassigning which orbit a given mass occupies. The orbit assignment is determined by the rank ordering, which is frozen. This separation is by design: it ensures $\lambda_{\text{seg}}$ and $\alpha_{\text{IMF}}$ are not entangled through the segregation mapping.

---

## 5. Method B (OT) – Experimental Implementation

> **⚠️ EXPERIMENTAL**: Method B is not recommended for production use. It has $O(N^2)$ time and memory complexity. Use only for methods papers, $N \lesssim 10^4$, or hybrid approaches on massive stars.

### 5.1 Core Algorithm

Treat segregation as entropic optimal transport:

1. **Cost matrix**: $C_{ij} = -m_i^\alpha \cdot (-e_j)^\beta$ (lower = better match)
2. **Sinkhorn algorithm**: Solve for transport plan $\Pi_{ij}$
3. **Soft assignment**: $\mathbf{x}_i = \sum_j \Pi_{ij} \mathbf{x}_j^{\text{orb}}$

### 5.2 Log-Domain Sinkhorn

```python
def log_sinkhorn(
    log_K: Array,      # (N, N_pool) log of kernel matrix
    log_a: Array,      # (N,) log of source marginal
    log_b: Array,      # (N_pool,) log of target marginal
    n_iters: int,
) -> Array:
    """Log-domain Sinkhorn algorithm.
    
    Returns log of transport plan: log(Π).
    """
    N, N_pool = log_K.shape
    
    log_u = jnp.zeros(N)
    log_v = jnp.zeros(N_pool)
    
    def sinkhorn_step(carry, _):
        log_u, log_v = carry
        log_u = log_a - jax.scipy.special.logsumexp(
            log_K + log_v[None, :], axis=1
        )
        log_v = log_b - jax.scipy.special.logsumexp(
            log_K.T + log_u[None, :], axis=1
        )
        return (log_u, log_v), None
    
    (log_u, log_v), _ = lax.scan(
        sinkhorn_step, (log_u, log_v), None, length=n_iters
    )
    
    log_Pi = log_u[:, None] + log_K + log_v[None, :]
    return log_Pi
```

### 5.3 OT Segregation

```python
@dataclass(frozen=True)
class OTSegregationParams:
    """Parameters for Method B (optimal transport).
    
    EXPERIMENTAL: O(N²) complexity. Use for N ≲ 10⁴ only.
    
    Attributes
    ----------
    lambda_seg : float
        Segregation strength in [0, 1].
    tau : float
        Entropic regularization. Smaller = sharper. Typical: 0.01–0.5.
    alpha, beta : float
        Exponents in cost function C = -m^α * E^β.
    n_sinkhorn_iters : int
        Number of Sinkhorn iterations.
    blend_mode : str
        'plan' = blend transport plans, 'cost' = blend cost matrices.
    """
    lambda_seg: float = 0.5
    tau: float = 0.1
    alpha: float = 1.0
    beta: float = 1.0
    n_sinkhorn_iters: int = 50
    pool_factor: int = 4
    virial_ratio: float = 0.5
    blend_mode: Literal["plan", "cost"] = "plan"


def ot_segregation(
    key: random.PRNGKey,
    masses: Array,
    orbit_positions: Array,
    orbit_velocities: Array,
    energies: Array,
    params: OTSegregationParams,
) -> tuple[Array, Array]:
    """Assign orbits using entropic optimal transport.
    
    ⚠️ WARNING: Allocates O(N × N_pool) memory. Not recommended for N > 10⁴.
    """
    N = masses.shape[0]
    N_pool = orbit_positions.shape[0]
    tau = params.tau
    lambda_seg = jnp.clip(params.lambda_seg, 0.0, 1.0)
    
    # Build cost matrices
    w_m = masses ** params.alpha
    binding_energy = jnp.maximum(-energies, 1e-10)  # Handle unbound orbits
    w_e = binding_energy ** params.beta
    
    C_seg = -w_m[:, None] * w_e[None, :]
    C_seg = C_seg / jnp.abs(C_seg).max()  # Normalize for stability
    C_null = jnp.zeros_like(C_seg)
    
    # Marginals (uniform)
    log_a = -jnp.log(N) * jnp.ones(N)
    log_b = -jnp.log(N_pool) * jnp.ones(N_pool)
    
    # Compute transport plan
    if params.blend_mode == "plan":
        log_K_null = -C_null / tau
        log_K_seg = -C_seg / tau
        
        log_Pi_null = log_sinkhorn(log_K_null, log_a, log_b, params.n_sinkhorn_iters)
        log_Pi_seg = log_sinkhorn(log_K_seg, log_a, log_b, params.n_sinkhorn_iters)
        
        Pi = (1 - lambda_seg) * jnp.exp(log_Pi_null) + lambda_seg * jnp.exp(log_Pi_seg)
    else:
        C_blend = (1 - lambda_seg) * C_null + lambda_seg * C_seg
        log_K = -C_blend / tau
        log_Pi = log_sinkhorn(log_K, log_a, log_b, params.n_sinkhorn_iters)
        Pi = jnp.exp(log_Pi)
    
    # Soft assignment (barycenter)
    Pi = Pi / Pi.sum(axis=1, keepdims=True)
    positions = Pi @ orbit_positions
    velocities = Pi @ orbit_velocities
    
    # Post-processing
    positions, velocities = virialize_and_center(
        positions, velocities, masses, params.virial_ratio, G
    )
    
    return positions, velocities
```

### 5.4 Scalable Variants (Summary)

For $N > 10^4$, consider these approaches (implementations in extended docs):

| Variant | Complexity | Memory | Best For |
|---------|------------|--------|----------|
| **Mini-batch Sinkhorn** | $O(B \cdot T \cdot N \cdot \text{batch})$ | $O(N \cdot \text{batch})$ | Large $N_{\text{pool}}$ |
| **Hierarchical OT** | $O(T \cdot N \cdot N_{\text{pool}} / K)$ | $O(N \cdot N_{\text{pool}} / K)$ | $N \sim 10^4$–$10^5$ |
| **Hybrid OT+Blend** | $O(n_{\text{massive}}^2 + N \log N)$ | $O(n_{\text{massive}} \cdot N_{\text{pool}})$ | **Recommended** |

**Recommended pattern**: Apply OT to the $N_{\text{massive}} \sim 50$–100 most massive stars (they dominate $\Lambda_{\text{MSR}}$) and blending to the rest.

---

## 6. Unified API & Configuration

### 6.1 Primary Entry Point

```python
# Type alias for all supported parameter types
SegregationParams = Union[
    BlendingSegregationParams,
    MassDependentSegregationParams,
    OTSegregationParams,
]


def assign_orbits_mass_seg(
    key: random.PRNGKey,
    masses: Array,
    orbit_positions: Array,
    orbit_velocities: Array,
    energies: Array,
    method: Literal["blend", "ot"] = "blend",
    params: SegregationParams | None = None,
) -> tuple[Array, Array]:
    """Unified API for mass segregation.
    
    Parameters
    ----------
    key : PRNGKey
    masses : (N,) stellar masses
    orbit_positions : (N_pool, 3) orbit pool positions
    orbit_velocities : (N_pool, 3) orbit pool velocities
    energies : (N_pool,) specific energies
    method : 'blend' (default, recommended) or 'ot' (experimental)
    params : Parameter dataclass. Accepts:
        - BlendingSegregationParams: scalar λ_seg blending (default)
        - MassDependentSegregationParams: mass-dependent λ_seg(m) blending
        - OTSegregationParams: optimal transport (experimental)
        If None, uses BlendingSegregationParams() for 'blend',
        OTSegregationParams() for 'ot'.
    
    Returns
    -------
    positions : (N, 3) assigned positions
    velocities : (N, 3) assigned velocities
    
    Notes
    -----
    For mass-dependent segregation, pass MassDependentSegregationParams
    with method='blend'. The function dispatches based on params type.
    """
    if params is None:
        params = BlendingSegregationParams() if method == "blend" else OTSegregationParams()
    
    if method == "blend":
        if isinstance(params, MassDependentSegregationParams):
            return blending_segregation_mass_dependent(
                key, masses, orbit_positions, orbit_velocities, energies, params
            )
        else:
            return blending_segregation(
                key, masses, orbit_positions, orbit_velocities, energies, params
            )
    elif method == "ot":
        return ot_segregation(
            key, masses, orbit_positions, orbit_velocities, energies, params
        )
    else:
        raise ValueError(f"Unknown method: {method}")
```

### 6.2 Shared Utilities

```python
def virialize_and_center(
    positions: Array,
    velocities: Array,
    masses: Array,
    target_Q_vir: float,
    G: float,
) -> tuple[Array, Array]:
    """Rescale velocities to target virial ratio and remove COM.
    
    NOTE: Uses O(N²) potential energy calculation. Acceptable for IC
    generation but should NOT be used in an N-body timestep loop.
    
    For gradient-based inference with large N in an inner loop (e.g., HMC),
    consider replacing compute_potential_energy with a tree/FMM approximation
    or a precomputed potential grid to avoid O(N²) scaling.
    """
    M_total = jnp.sum(masses)
    
    U = compute_potential_energy(positions, masses, G)
    
    K_current = 0.5 * jnp.sum(masses[:, None] * velocities**2)
    K_target = target_Q_vir * jnp.abs(U)
    
    scale = jnp.sqrt(K_target / jnp.maximum(K_current, 1e-10))
    velocities = velocities * scale
    
    # Remove COM velocity
    v_com = jnp.sum(masses[:, None] * velocities, axis=0) / M_total
    velocities = velocities - v_com
    
    # Center positions
    x_com = jnp.sum(masses[:, None] * positions, axis=0) / M_total
    positions = positions - x_com
    
    return positions, velocities


def compute_potential_energy(
    positions: Array,
    masses: Array,
    G: float,
    softening: float = 1e-4,
) -> float:
    """Compute total gravitational potential energy.
    
    O(N²) direct summation. Use only for IC generation.
    """
    diff = positions[:, None, :] - positions[None, :, :]
    r_ij = jnp.sqrt(jnp.sum(diff**2, axis=-1) + softening**2)
    m_ij = masses[:, None] * masses[None, :]
    mask = jnp.triu(jnp.ones_like(r_ij, dtype=bool), k=1)
    U = -G * jnp.sum(jnp.where(mask, m_ij / r_ij, 0.0))
    return U
```

---

## 7. Testing Strategy

### 7.1 Test Map

| Test | Function | Priority | Validates |
|------|----------|----------|-----------|
| Gradient flow | `test_gradient_flow` | **v1 required** | Differentiability invariant |
| Λ_MSR monotonicity | `test_lambda_msr_monotonic` | **v1 required** | Statistical invariant |
| ρ_ME monotonicity | `test_mass_energy_correlation` | **v1 required** | Statistical invariant |
| Endpoint consistency | `test_blend_endpoints` | **v1 required** | Boundary behavior |
| Mass-radius correlation | `test_mass_radius_correlation` | **v1 required** | Observable response |
| Mass-dependent params | `test_mass_dependent_sensitivity` | v1.1 | λ_base/λ_slope response |
| FDF orthogonality | `test_fdf_orthogonality` | **v1 required** | Parameter independence |
| OT marginal validity | `test_ot_plan_validity` | v1.1 (OT) | OT constraints |
| OT plan continuity | `test_ot_plan_continuity` | v1.1 (OT) | Smooth λ_seg response |
| OT vs blend consistency | `test_ot_blend_consistency` | v1.1 (OT) | Method agreement |
| Performance scaling | `test_scaling` | Optional | Benchmarks |

> **Test setup note:** All tests assume `masses`, `pos_pool`, `vel_pool`, `energies`, and `potential_fn` are constructed earlier in the test module. See test fixtures in `tests/test_segregation.py`.

### 7.2 Gradient Flow Test

```python
def test_gradient_flow():
    """Verify gradients flow through lambda_seg for both methods."""
    
    def loss_blend(lambda_seg):
        params = BlendingSegregationParams(lambda_seg=lambda_seg)
        key = random.PRNGKey(0)
        
        masses = jnp.array([10.0, 5.0, 3.0, 1.0, 0.5])
        pos_pool = random.normal(key, (20, 3))
        vel_pool = random.normal(key, (20, 3)) * 0.1
        energies = -1.0 / jnp.linalg.norm(pos_pool, axis=1)
        
        positions, _ = blending_segregation(
            key, masses, pos_pool, vel_pool, energies, params
        )
        
        # Observable: mean radius of top 2 most massive
        order = jnp.argsort(-masses)[:2]
        return jnp.mean(jnp.linalg.norm(positions[order], axis=1))
    
    grad_blend = jax.grad(loss_blend)(0.5)
    
    assert jnp.abs(grad_blend) > 1e-6, "Blend gradient is zero"
    print(f"✓ Blend gradient: {grad_blend:.4f}")
```

### 7.3 Mass-Energy Rank Correlation Test (ρ_ME)

```python
def compute_rho_ME(positions, velocities, masses, potential_fn):
    """Compute Spearman rank correlation between mass and binding energy.
    
    This is the core metric for mass segregation: ρ_ME ≈ 0 means no
    correlation, ρ_ME → 1 means perfect mass-energy rank matching.
    """
    from scipy.stats import spearmanr
    
    # Compute assigned energies from final positions/velocities
    e_assigned = 0.5 * jnp.sum(velocities**2, axis=1) + potential_fn(positions)
    
    # Spearman correlation: mass vs binding energy (-e)
    rho, _ = spearmanr(np.array(masses), -np.array(e_assigned))
    return rho


def test_mass_energy_correlation():
    """Verify ρ_ME increases monotonically with λ_seg."""
    key = random.PRNGKey(42)
    lambda_values = [0.0, 0.25, 0.5, 0.75, 1.0]
    rho_values = []
    
    for lam in lambda_values:
        params = BlendingSegregationParams(lambda_seg=lam)
        positions, velocities = blending_segregation(
            key, masses, pos_pool, vel_pool, energies, params
        )
        
        rho = compute_rho_ME(positions, velocities, masses, potential_fn)
        rho_values.append(rho)
    
    # Check monotonicity (with tolerance for MC noise)
    for i in range(len(rho_values) - 1):
        assert rho_values[i+1] >= rho_values[i] - 0.1, \
            f"ρ_ME not monotonic at λ={lambda_values[i+1]}"
    
    # Check endpoint behavior
    assert abs(rho_values[0]) < 0.3, f"ρ_ME at λ=0 should be ~0, got {rho_values[0]}"
    assert rho_values[-1] > 0.8, f"ρ_ME at λ=1 should be high, got {rho_values[-1]}"
    
    print(f"✓ ρ_ME monotonic: {[f'{r:.3f}' for r in rho_values]}")
```

### 7.4 Λ_MSR Monotonicity Test

```python
def test_lambda_msr_monotonic():
    """Verify Λ_MSR increases with lambda_seg."""
    from progenax.diagnostics import compute_lambda_msr
    
    key = random.PRNGKey(42)
    lambda_values = [0.0, 0.25, 0.5, 0.75, 1.0]
    msr_values = []
    
    for lam in lambda_values:
        params = BlendingSegregationParams(lambda_seg=lam)
        positions, _ = blending_segregation(
            key, masses, pos_pool, vel_pool, energies, params
        )
        
        lam_msr, _ = compute_lambda_msr(
            np.array(positions), np.array(masses), N_massive=10
        )
        msr_values.append(lam_msr)
    
    # Check monotonicity (with tolerance for MC noise)
    for i in range(len(msr_values) - 1):
        assert msr_values[i+1] >= msr_values[i] - 0.1, \
            f"Λ_MSR not monotonic at λ={lambda_values[i+1]}"
    
    print(f"✓ Λ_MSR monotonic: {msr_values}")
```

### 7.5 Mass-Radius Correlation Test

```python
def test_mass_radius_correlation():
    """Verify massive stars become more centrally concentrated with λ_seg."""
    key = random.PRNGKey(42)
    lambda_values = [0.0, 0.5, 1.0]
    
    def compute_delta_r(positions, masses, n_massive=20):
        """Difference in mean radius: top mass decile - bottom mass decile."""
        radii = jnp.linalg.norm(positions, axis=1)
        mass_order = jnp.argsort(-masses)
        
        # Top decile (most massive)
        r_top = jnp.mean(radii[mass_order[:n_massive]])
        # Bottom decile (least massive)
        r_bottom = jnp.mean(radii[mass_order[-n_massive:]])
        
        return r_top - r_bottom  # Negative = massive stars more concentrated
    
    delta_r_values = []
    
    for lam in lambda_values:
        params = BlendingSegregationParams(lambda_seg=lam)
        positions, _ = blending_segregation(
            key, masses, pos_pool, vel_pool, energies, params
        )
        
        delta_r = compute_delta_r(positions, masses)
        delta_r_values.append(delta_r)
    
    # Δr should decrease (become more negative) as λ_seg increases
    for i in range(len(delta_r_values) - 1):
        assert delta_r_values[i+1] <= delta_r_values[i] + 0.1, \
            f"Δr not decreasing at λ={lambda_values[i+1]}"
    
    print(f"✓ Δr (massive - low mass): {[f'{dr:.3f}' for dr in delta_r_values]}")
```

### 7.6 Mass-Dependent Parameters Sensitivity Test

```python
def test_mass_dependent_sensitivity():
    """Verify λ_base and λ_slope have expected effects."""
    key = random.PRNGKey(42)
    
    # Test 1: λ_slope = 0 should recover scalar behavior
    lambda_ref = 0.5
    params_scalar = BlendingSegregationParams(lambda_seg=lambda_ref)
    params_mass_dep = MassDependentSegregationParams(
        lambda_base=lambda_ref, lambda_slope=0.0
    )
    
    pos_scalar, vel_scalar = blending_segregation(
        key, masses, pos_pool, vel_pool, energies, params_scalar
    )
    pos_mass_dep, vel_mass_dep = blending_segregation_mass_dependent(
        key, masses, pos_pool, vel_pool, energies, params_mass_dep
    )
    
    rho_scalar = compute_rho_ME(pos_scalar, vel_scalar, masses, potential_fn)
    rho_mass_dep = compute_rho_ME(pos_mass_dep, vel_mass_dep, masses, potential_fn)
    
    assert abs(rho_scalar - rho_mass_dep) < 0.1, \
        f"λ_slope=0 should match scalar: {rho_scalar:.3f} vs {rho_mass_dep:.3f}"
    
    # Test 2: Increasing λ_slope should increase Δr between mass bins
    slope_values = [0.0, 0.2, 0.4]
    delta_r_values = []
    
    for slope in slope_values:
        params = MassDependentSegregationParams(lambda_base=0.3, lambda_slope=slope)
        positions, _ = blending_segregation_mass_dependent(
            key, masses, pos_pool, vel_pool, energies, params
        )
        
        delta_r = compute_delta_r(positions, masses)
        delta_r_values.append(delta_r)
    
    # Δr should decrease (more negative) as slope increases
    for i in range(len(delta_r_values) - 1):
        assert delta_r_values[i+1] <= delta_r_values[i] + 0.05, \
            f"Δr not responding to λ_slope at slope={slope_values[i+1]}"
    
    print(f"✓ Mass-dependent params sensitivity verified")
```

### 7.7 FDF Orthogonality Test

```python
def test_fdf_orthogonality():
    """Verify λ_seg and λ_frac control independent aspects of structure.
    
    λ_seg should strongly affect Λ_MSR, weakly affect Q (clumpiness).
    λ_frac should strongly affect Q, weakly affect Λ_MSR.
    """
    from progenax.diagnostics import compute_lambda_msr, compute_Q_parameter
    from progenax.fdf import apply_fdf_displacement
    
    key = random.PRNGKey(42)
    
    # 2x2 grid: (λ_seg, λ_frac) ∈ {0, 1} × {0, 1}
    results = {}
    
    for lam_seg in [0.0, 1.0]:
        for lam_frac in [0.0, 1.0]:
            key, k1, k2 = random.split(key, 3)
            
            # Segregation
            params = BlendingSegregationParams(lambda_seg=lam_seg)
            positions, velocities = blending_segregation(
                k1, masses, pos_pool, vel_pool, energies, params
            )
            
            # FDF displacement
            positions_fdf = apply_fdf_displacement(
                k2, positions, fractal_field, lambda_frac=lam_frac
            )
            
            # Compute metrics
            lam_msr, _ = compute_lambda_msr(np.array(positions_fdf), np.array(masses), N_massive=10)
            Q = compute_Q_parameter(np.array(positions_fdf))
            
            results[(lam_seg, lam_frac)] = {'msr': lam_msr, 'Q': Q}
    
    # Check orthogonality: Λ_MSR should depend mainly on λ_seg
    msr_diff_seg = abs(results[(1.0, 0.0)]['msr'] - results[(0.0, 0.0)]['msr'])
    msr_diff_frac = abs(results[(1.0, 1.0)]['msr'] - results[(1.0, 0.0)]['msr'])
    
    assert msr_diff_seg > 2 * msr_diff_frac, \
        f"Λ_MSR should depend more on λ_seg than λ_frac: Δseg={msr_diff_seg:.3f}, Δfrac={msr_diff_frac:.3f}"
    
    # Check orthogonality: Q should depend mainly on λ_frac
    Q_diff_frac = abs(results[(0.0, 1.0)]['Q'] - results[(0.0, 0.0)]['Q'])
    Q_diff_seg = abs(results[(1.0, 0.0)]['Q'] - results[(0.0, 0.0)]['Q'])
    
    assert Q_diff_frac > 2 * Q_diff_seg, \
        f"Q should depend more on λ_frac than λ_seg: Δfrac={Q_diff_frac:.3f}, Δseg={Q_diff_seg:.3f}"
    
    print(f"✓ FDF orthogonality verified: λ_seg controls Λ_MSR, λ_frac controls Q")
```

### 7.8 Endpoint Consistency Test

```python
def test_blend_endpoints():
    """Verify λ=0 and λ=1 produce different ICs with correct properties."""
    key = random.PRNGKey(0)
    
    params_0 = BlendingSegregationParams(lambda_seg=0.0)
    pos_0, vel_0 = blending_segregation(key, masses, pos_pool, vel_pool, energies, params_0)
    
    params_1 = BlendingSegregationParams(lambda_seg=1.0)
    pos_1, vel_1 = blending_segregation(key, masses, pos_pool, vel_pool, energies, params_1)
    
    # Check they're different
    assert not jnp.allclose(pos_0, pos_1), "Endpoints should differ"
    
    # Check mass-energy correlation at λ=1
    rho_0 = compute_rho_ME(pos_0, vel_0, masses, potential_fn)
    rho_1 = compute_rho_ME(pos_1, vel_1, masses, potential_fn)
    
    assert rho_1 > rho_0 + 0.5, f"λ=1 should have much higher ρ_ME than λ=0"
    assert rho_1 > 0.8, f"Weak mass-energy correlation at λ=1: {rho_1}"
    
    print("✓ Endpoint consistency passed")
```

### 7.9 OT Plan Validity Test

```python
def test_ot_plan_validity():
    """Verify OT plan satisfies marginal constraints."""
    key = random.PRNGKey(0)
    
    N, N_pool = 100, 400
    masses = random.uniform(key, (N,)) + 0.1
    energies = -random.uniform(key, (N_pool,)) - 0.1
    
    # Build cost and run Sinkhorn
    w_m = masses
    w_e = -energies
    C = -w_m[:, None] * w_e[None, :]
    C = C / jnp.abs(C).max()
    
    tau = 0.1
    log_K = -C / tau
    log_a = -jnp.log(N) * jnp.ones(N)
    log_b = -jnp.log(N_pool) * jnp.ones(N_pool)
    
    log_Pi = log_sinkhorn(log_K, log_a, log_b, n_iters=50)
    Pi = jnp.exp(log_Pi)
    
    # Check marginals
    row_sums = Pi.sum(axis=1)
    col_sums = Pi.sum(axis=0)
    
    assert jnp.allclose(row_sums, 1/N, atol=1e-3), "Row marginal violated"
    assert jnp.allclose(col_sums, 1/N_pool, atol=1e-3), "Col marginal violated"
    
    print("✓ OT marginals satisfied")
```

### 7.10 OT Plan Continuity Test

```python
def test_ot_plan_continuity():
    """Verify transport plan varies smoothly with λ_seg (cost blending mode)."""
    key = random.PRNGKey(0)
    
    N, N_pool = 50, 200
    masses = random.uniform(key, (N,)) + 0.1
    pos_pool = random.normal(key, (N_pool, 3))
    vel_pool = random.normal(key, (N_pool, 3)) * 0.1
    energies = -1.0 / jnp.linalg.norm(pos_pool, axis=1)
    
    # Compare plans at λ=0.4 and λ=0.5
    params_04 = OTSegregationParams(lambda_seg=0.4, tau=0.1, blend_mode="cost")
    params_05 = OTSegregationParams(lambda_seg=0.5, tau=0.1, blend_mode="cost")
    
    pos_04, _ = ot_segregation(key, masses, pos_pool, vel_pool, energies, params_04)
    pos_05, _ = ot_segregation(key, masses, pos_pool, vel_pool, energies, params_05)
    
    # Positions should be close (smooth variation)
    diff = jnp.linalg.norm(pos_05 - pos_04) / jnp.linalg.norm(pos_04)
    
    assert diff < 0.5, f"OT positions not continuous in λ_seg: relative diff = {diff:.3f}"
    
    print(f"✓ OT plan continuity: relative position diff = {diff:.4f}")
```

### 7.11 OT vs Blend Consistency Test

```python
def test_ot_blend_consistency():
    """Verify OT and blend give similar results at high λ_seg, small τ."""
    key = random.PRNGKey(0)
    
    N, N_pool = 100, 100  # Equal sizes for fair comparison
    masses = random.uniform(key, (N,)) + 0.1
    pos_pool = random.normal(key, (N_pool, 3))
    vel_pool = random.normal(key, (N_pool, 3)) * 0.1
    energies = -1.0 / jnp.linalg.norm(pos_pool, axis=1)
    
    # Blend at λ=1
    params_blend = BlendingSegregationParams(lambda_seg=1.0)
    pos_blend, vel_blend = blending_segregation(key, masses, pos_pool, vel_pool, energies, params_blend)
    
    # OT at λ=1, small τ
    params_ot = OTSegregationParams(lambda_seg=1.0, tau=0.01)
    pos_ot, vel_ot = ot_segregation(key, masses, pos_pool, vel_pool, energies, params_ot)
    
    # Compute metrics
    rho_blend = compute_rho_ME(pos_blend, vel_blend, masses, potential_fn)
    rho_ot = compute_rho_ME(pos_ot, vel_ot, masses, potential_fn)
    
    assert abs(rho_blend - rho_ot) < 0.15, \
        f"OT and blend should give similar ρ_ME at λ=1: {rho_blend:.3f} vs {rho_ot:.3f}"
    
    print(f"✓ OT vs blend consistency: ρ_ME = {rho_blend:.3f} (blend) vs {rho_ot:.3f} (OT)")
```

---

## 8. Performance & Scaling Notes

### 8.1 Expected Scaling

| Method | Time | Memory | JIT Compile |
|--------|------|--------|-------------|
| Method A (blend) | $O(N \log N)$ | $O(N)$ | ~1s first call |
| Method B (OT) | $O(T \cdot N \cdot N_{\text{pool}})$ | $O(N \cdot N_{\text{pool}})$ | ~3s first call |

### 8.2 Practical Limits

- **Method A**: Tested up to $N = 10^6$
- **Method B**: Recommended $N \lesssim 10^4$, hard limit ~$5 \times 10^4$ on 16GB GPU

### 8.3 JIT Considerations

Both functions are JIT-compatible:

```python
blending_seg_jit = jax.jit(blending_segregation)
```

**Tracing note:** The function retraces if `N` or `N_pool` changes. For batch inference with varying cluster sizes, consider padding to fixed sizes or using `jax.vmap` with padded arrays.

### 8.4 Gradient Checkpointing

For large $N$ with memory constraints during backward pass:

```python
from jax.checkpoint import checkpoint

@checkpoint
def segregation_step(masses, orbit_pool, params, key):
    return blending_segregation(
        key, masses,
        orbit_pool.positions, orbit_pool.velocities, orbit_pool.energies,
        params,
    )
```

**Tradeoff:** Halves peak memory at ~1.5× compute cost.

---

## 9. Integration Points

### 9.1 Upstream: DF Sampler

The segregation module receives its orbit pool from the equilibrium DF sampler:

```python
from progenax.profiles import sample_equilibrium_df

orbit_pool = sample_equilibrium_df(key, profile, N_pool=pool_factor * N)
# Returns: orbit_pool.positions, orbit_pool.velocities, orbit_pool.energies
```

### 9.2 Downstream: FDF Displacement

FDF is applied **after** segregation:

```python
# Step 1: Segregation assigns orbits by mass
positions, velocities = assign_orbits_mass_seg(
    key, masses, orbit_pool.positions, orbit_pool.velocities, orbit_pool.energies,
    method="blend", params=BlendingSegregationParams(lambda_seg=0.5)
)

# Step 2: FDF applies spatial clumpiness (optional)
positions_fdf = apply_fdf_displacement(
    key, positions, fractal_field, lambda_frac=0.5
)
```

**Key insight:** $\lambda_{\text{seg}}$ and $\lambda_{\text{frac}}$ are **orthogonal** controls (validated in §7.7):
- $\lambda_{\text{seg}}$: Who gets which orbits (mass-energy correlation)
- $\lambda_{\text{frac}}$: Where stars are placed (geometric clumpiness)

### 9.3 Downstream: N-body / Renderer

The output IC snapshot feeds into the N-body integrator or renderer:

```python
ic = ClusterIC(positions=positions_fdf, velocities=velocities, masses=masses)
observables = render_cluster(ic, observation_params)
loss = likelihood(observables, data)
```

### 9.4 Gradient Flow Summary

| Parameter | Gradients Through Segregation | Notes |
|-----------|------------------------------|-------|
| `lambda_seg` | ✓ Direct | $\partial \mathbf{x}/\partial \lambda = \mathbf{x}^{\text{seg}} - \mathbf{x}^{\text{rand}}$ |
| `lambda_base`, `lambda_slope` | ✓ Direct | Mass-dependent variant |
| `theta_profile` | ✓ If pool not frozen | Via orbit positions |
| `lambda_frac` | ✓ Through FDF | Orthogonal to λ_seg |
| `theta_IMF` | ✗ Through permutation | Blocked by argsort |
| `theta_IMF` | ✓ Other paths | Stellar physics, luminosities, mass function |

---

## 10. Visualization Hooks for Methods Paper

The following visualization patterns connect directly to the APIs in this guide and validate the design invariants. See the methods paper prep document for full figure specifications.

### 10.1 Mass-Energy Scatter Plots vs λ_seg

**Figure concept:** 3-panel figure showing (log mass) vs (binding energy) scatter plots for $\lambda_{\text{seg}} = 0, 0.5, 1$.

```python
def generate_mass_energy_scatter_data(key, lambda_values=[0.0, 0.5, 1.0]):
    """Generate data for mass-energy scatter visualization."""
    results = []
    
    for lam in lambda_values:
        params = BlendingSegregationParams(lambda_seg=lam)
        positions, velocities = blending_segregation(
            key, masses, pos_pool, vel_pool, energies, params
        )
        
        e_assigned = 0.5 * jnp.sum(velocities**2, axis=1) + potential_fn(positions)
        rho = compute_rho_ME(positions, velocities, masses, potential_fn)
        
        results.append({
            'lambda_seg': lam,
            'masses': masses,
            'binding_energy': -e_assigned,  # Positive for bound
            'rho_ME': rho,
        })
    
    return results
```

**Expected behavior:** At $\lambda_{\text{seg}} = 0$, scatter is uncorrelated; at $\lambda_{\text{seg}} = 1$, clear positive correlation between mass and binding energy. Annotate each panel with computed $\rho_{\text{ME}}$.

### 10.2 Radial CDF by Mass Bin

**Figure concept:** 3-panel figure showing cumulative radial distributions for different mass bins.

```python
def generate_radial_cdf_data(key, lambda_values=[0.0, 0.5, 1.0], n_bins=3):
    """Generate data for radial CDF by mass bin visualization."""
    results = []
    
    for lam in lambda_values:
        params = BlendingSegregationParams(lambda_seg=lam)
        positions, _ = blending_segregation(
            key, masses, pos_pool, vel_pool, energies, params
        )
        
        radii = jnp.linalg.norm(positions, axis=1)
        mass_order = jnp.argsort(masses)
        bin_size = len(masses) // n_bins
        
        cdfs = {}
        for i, label in enumerate(['low', 'mid', 'high']):
            if i < n_bins - 1:
                idx = mass_order[i * bin_size:(i + 1) * bin_size]
            else:
                idx = mass_order[i * bin_size:]
            cdfs[label] = jnp.sort(radii[idx])
        
        results.append({'lambda_seg': lam, 'cdfs': cdfs})
    
    return results
```

**Expected behavior:** At $\lambda_{\text{seg}} = 0$, CDFs overlap; at $\lambda_{\text{seg}} = 1$, high-mass CDF shifted strongly inward. Referees love this kind of CDF comparison.

### 10.3 Response Curves: Λ_MSR and ρ_ME vs λ_seg

**Figure concept:** Line plots with error bars showing monotonic response of metrics to $\lambda_{\text{seg}}$.

```python
def generate_response_curves(key, n_seeds=10, n_lambda=11):
    """Generate response curves with error bars."""
    lambda_values = jnp.linspace(0, 1, n_lambda)
    
    msr_all = []
    rho_all = []
    
    for seed in range(n_seeds):
        key_i = random.PRNGKey(seed)
        msr_seed = []
        rho_seed = []
        
        for lam in lambda_values:
            params = BlendingSegregationParams(lambda_seg=float(lam))
            positions, velocities = blending_segregation(
                key_i, masses, pos_pool, vel_pool, energies, params
            )
            
            lam_msr, _ = compute_lambda_msr(np.array(positions), np.array(masses), N_massive=10)
            rho = compute_rho_ME(positions, velocities, masses, potential_fn)
            
            msr_seed.append(lam_msr)
            rho_seed.append(rho)
        
        msr_all.append(msr_seed)
        rho_all.append(rho_seed)
    
    return {
        'lambda_values': lambda_values,
        'msr_mean': np.mean(msr_all, axis=0),
        'msr_std': np.std(msr_all, axis=0),
        'rho_mean': np.mean(rho_all, axis=0),
        'rho_std': np.std(rho_all, axis=0),
    }
```

**Expected behavior:** Monotonically increasing curves with small error bars, validating statistical invariant. This sells $\lambda_{\text{seg}}$ as a legitimate inference parameter—it has a nice smooth response, not some weird jagged surface.

### 10.4 λ_seg–λ_frac Orthogonality Heatmap

**Figure concept:** Two 2D heatmaps showing Λ_MSR(λ_seg, λ_frac) and Q(λ_seg, λ_frac).

```python
def generate_orthogonality_heatmap(key, n_grid=5):
    """Generate 2D heatmap data for orthogonality visualization."""
    lambda_seg_values = jnp.linspace(0, 1, n_grid)
    lambda_frac_values = jnp.linspace(0, 1, n_grid)
    
    msr_grid = np.zeros((n_grid, n_grid))
    Q_grid = np.zeros((n_grid, n_grid))
    
    for i, lam_seg in enumerate(lambda_seg_values):
        for j, lam_frac in enumerate(lambda_frac_values):
            key, k1, k2 = random.split(key, 3)
            
            params = BlendingSegregationParams(lambda_seg=float(lam_seg))
            positions, _ = blending_segregation(
                k1, masses, pos_pool, vel_pool, energies, params
            )
            
            positions_fdf = apply_fdf_displacement(
                k2, positions, fractal_field, lambda_frac=float(lam_frac)
            )
            
            msr_grid[i, j], _ = compute_lambda_msr(np.array(positions_fdf), np.array(masses), N_massive=10)
            Q_grid[i, j] = compute_Q_parameter(np.array(positions_fdf))
    
    return {
        'lambda_seg': lambda_seg_values,
        'lambda_frac': lambda_frac_values,
        'msr': msr_grid,
        'Q': Q_grid,
    }
```

**Expected behavior:** Λ_MSR varies mainly along λ_seg axis; Q varies mainly along λ_frac axis. This makes a very strong "these parameters control different physics" statement.

### 10.5 OT vs Blending Comparison for Massive Stars

**Figure concept:** Radial CDF comparison for top 20 most massive stars between pure blend and hybrid OT+blend.

```python
def generate_ot_blend_comparison(key, n_massive=20):
    """Compare blend vs OT for massive stars."""
    # Blend-only
    params_blend = BlendingSegregationParams(lambda_seg=1.0)
    pos_blend, _ = blending_segregation(
        key, masses, pos_pool, vel_pool, energies, params_blend
    )
    
    # OT for comparison (if implemented)
    params_ot = OTSegregationParams(lambda_seg=1.0, tau=0.01)
    pos_ot, _ = ot_segregation(
        key, masses, pos_pool, vel_pool, energies, params_ot
    )
    
    # Get radii for top N massive
    mass_order = jnp.argsort(-masses)[:n_massive]
    
    r_blend = jnp.sort(jnp.linalg.norm(pos_blend[mass_order], axis=1))
    r_ot = jnp.sort(jnp.linalg.norm(pos_ot[mass_order], axis=1))
    
    return {
        'r_blend': r_blend,
        'r_ot': r_ot,
        'n_massive': n_massive,
    }
```

**Expected behavior:** CDFs should be similar, justifying "blending is good enough for most purposes, OT is a fancier variant."

---

## Appendix: Quick Reference

### Parameter Defaults

**Method A (Blending)** — RECOMMENDED
```
lambda_seg = 0.5    # [0, 1] segregation strength
pool_factor = 4     # N_pool = 4N
virial_ratio = 0.5  # Q_vir = K/|U|

Complexity: O(N log N)
Use for: All production applications
```

**Mass-Dependent Blending**
```
lambda_base = 0.3   # segregation at 1 M_sun
lambda_slope = 0.2  # increase per dex of mass (0 = scalar model)

Priors: lambda_base ~ U(0,1), lambda_slope ~ HalfNormal or truncated
```

**Method B (OT)** — Experimental
```
lambda_seg = 0.5    # [0, 1] segregation strength
tau = 0.1           # entropic temperature (smaller = sharper)
alpha = beta = 1.0  # cost function exponents
n_sinkhorn_iters = 50

Complexity: O(T·N·N_pool) ≈ O(N²)
Use for: Methods papers, N ≲ 10⁴, hybrid on top N_massive
```

### Key Metrics

| Metric | Symbol | Range | λ_seg=0 | λ_seg=1 |
|--------|--------|-------|---------|---------|
| Mass segregation ratio | Λ_MSR | [1, ∞) | ~1 | >2 |
| Mass-energy correlation | ρ_ME | [-1, 1] | ~0 | >0.8 |
| Radius difference | Δr | (-∞, ∞) | ~0 | <0 |

---

*Document v1.1 — Developer implementation guide for progenax mass segregation module. Includes design invariants, enhanced validation tests, FDF orthogonality verification, and visualization hooks. Method A is production-ready; Method B is experimental.*
